from google.cloud import bigquery
from google.cloud.exceptions import NotFound

def copy_table_capi(event, context):
  # try:
  if "source" in event:
    source = event["source"]
  else:
    raise("Error: source not found. Stopping process")

  if "destiny" in event:
    destiny = event["destiny"]
  else:
    raise("Error: destiny not found. Stopping process")

  # Construct a BigQuery client object.
  client = bigquery.Client()

  dest_table_id = destiny
  table_ids = source

  try:
    client.get_table(dest_table_id)
    print("The destiny table {} already existis.".format(dest_table_id))
    print("The tables {} haven't been appended to {}".format(table_ids, dest_table_id))
  except NotFound:
    job = client.copy_table(table_ids, dest_table_id)  # Make an API request.
    job.result()  # Wait for the job to complete.
    print("The tables {} have been appended to {}".format(table_ids, dest_table_id))