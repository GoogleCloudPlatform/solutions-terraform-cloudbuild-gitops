import os
from google.cloud import pubsub_v1
def hello_world(request):
    try:
        #testAttribute = request.get_json()
        publisher = pubsub_v1.PublisherClient()
        topic_name = 'projects/baymanagement/topics/anton-test'.format(
            project_id='baymanagement',
            topic='anton-test',
        )
        print(os.getenv('GOOGLE_CLOUD_PROJECT'))
        publisher.publish(topic_name, b'data for CF', testAttribute="Check data from CF")
        return f"OK"
    except:
        return f"Not OK"